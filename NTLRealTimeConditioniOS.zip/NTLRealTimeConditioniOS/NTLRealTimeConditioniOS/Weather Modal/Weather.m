//
//  Weather.m
//  AppForLiminology View
//
//  Created by Junjie on 16/1/2.
//  Copyright © 2016年 Junjie. All rights reserved.
//

#import "Weather.h"

@implementation Weather

// Insert code here to add functionality to your managed object subclass


@end
