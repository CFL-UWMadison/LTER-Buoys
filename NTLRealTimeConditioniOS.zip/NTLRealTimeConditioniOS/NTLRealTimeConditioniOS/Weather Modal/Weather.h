//
//  Weather.h
//  AppForLiminology View
//
//  Created by Junjie on 16/1/2.
//  Copyright © 2016年 Junjie. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Weather : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Weather+CoreDataProperties.h"
