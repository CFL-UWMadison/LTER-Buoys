NTL RealTime Condition for iOS:
    This app is used for displaying the latest lake weather data on the server of Argyon of the Center of Limnology. Besides the function, this app allows user to set its first page.

    This version currently only support iOS 8 and iOS 9. It should fit different kind of device with different screen size. Itis programmed under the standard library and the UIKit provided by Apple for its developer to create userinterface.The local data is preserved by Core Data provided by Apple

    There currently is no known bug which can crash the program.